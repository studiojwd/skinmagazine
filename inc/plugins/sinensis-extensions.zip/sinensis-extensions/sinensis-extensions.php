<?php
/**
 * @package Sinensis_Extensions
 * @version 1.0
 */
/*
Plugin Name: Sinensis Extensions
Plugin URI: http://juarathemes.com
Description: Extensions for Sinensis theme.
Author: Azhari Subroto
Version: 1.1
Author URI: http://juarathemes.com
*/

if(!function_exists('Sinensis_Extensions')){

}

require_once plugin_dir_path(__FILE__) . 'widgets/storm-twitter/TwitterAPIExchange.php';
require plugin_dir_path(__FILE__) . 'widgets/twitter-zl.php';
require plugin_dir_path(__FILE__) . 'slideshowgallery.php';
?>
